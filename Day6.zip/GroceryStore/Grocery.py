from flask import Flask ,request, render_template
app =Flask(__name__)

data = [{"vname":"carrot","qty":10 },{"vname":"potato","qty":20},{"vname":"peas","qty":30}
       ,{"vname":'onion',"qty":40}]

@app.route('/')
def index():
    return "Grocery List"

@app.route('/veggies')
def veggies():
   return render_template("grocerylist.html",var=data)

@app.route('/veggies/<vegetable>',methods=['GET'])
def veg(vegetable):
     if request.method=='GET':
        for veg in data:
            if vegetable == veg['vname']:
                return veg
        else:
            return "No Vegetable found"
       
   